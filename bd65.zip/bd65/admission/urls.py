from django.urls import path
from admission import views

urlpatterns = [
    path('',views.index),
    path('MOU',views.MOU),
    path('quatar',views.quatar),
    path('tcas1',views.tcas1),
    path('tcas2',views.tcas2),
    path('tcas3',views.tcas3),
    path('tcas4',views.tcas4),

   
]
