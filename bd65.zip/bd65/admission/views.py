from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def index (request):
    return render(request,"index.html")

def MOU(reqeust):
    return render(reqeust,"MOU.html")

def quatar(reqeust):
    return render(reqeust,"quatar.html")

def tcas1(request):
    return render(request,"tcas1.html")

def tcas2(request):
    return render(request,"tcas2.html")

def tcas3(request):
    return render(request,"tcas3.html")

def tcas4(request):
    return render(request,"tcas4.html")

